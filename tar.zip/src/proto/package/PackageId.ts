// Original file: proto/package.proto


export interface PackageId {
  'id'?: (string);
}

export interface PackageId__Output {
  'id'?: (string);
}

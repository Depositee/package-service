// Original file: null


export interface Empty {
}

export interface Empty__Output {
}
